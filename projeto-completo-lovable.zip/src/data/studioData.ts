/**
 * Brenda No Seu Studio - Informações Centrais e Configurações
 */

export const STUDIO_CONFIG = {
  brandName: 'Brenda No Seu Studio',
  tagline: 'De visitante a cliente em um clique!',
  phoneDisplay: '(11) 93907-1706',
  phoneRaw: '5511939071706',
  instagramHandle: '@brendanoseustudio',
  instagramUrl: 'https://instagram.com/brendanoseustudio',
  location: 'Brasil (Atendimento Nacional)',
  whatsappBaseUrl: 'https://wa.me/5511939071706',
};

export const getWhatsAppLink = (message?: string) => {
  const defaultMsg = 'Olá Brenda! Conheci seu trabalho pelo site e gostaria de solicitar um orçamento para a minha empresa.';
  const text = message ? encodeURIComponent(message) : encodeURIComponent(defaultMsg);
  return `${STUDIO_CONFIG.whatsappBaseUrl}?text=${text}`;
};

export interface ServiceItem {
  id: string;
  budgetIndex: string;
  title: string;
  category: 'landing' | 'institucional' | 'catalogo';
  categoryLabel: string;
  shortDescription: string;
  fullDescription: string;
  deliveryTime: string;
  highlightBadge?: string;
  features: string[];
  idealFor: string;
}

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'landing-page',
    budgetIndex: 'Orçamento 01',
    title: 'Landing Page de Alta Conversão',
    category: 'landing',
    categoryLabel: 'Campanhas & Anúncios',
    shortDescription: 'Página única ultra-estratégica desenhada para transformar tráfego pago (Google e Meta Ads) em orçamentos imediatos no WhatsApp.',
    fullDescription: 'Estrutura estratégica de copywriting e design de alto padrão desenvolvida especificamente para campanhas de Google Ads, Meta Ads e tráfego orgânico. O visitante entra, compreende o valor único do seu negócio e clica para fechar.',
    deliveryTime: '⚡ Opção de Entrega no Mesmo Dia (24h)',
    highlightBadge: 'Mais Solicitado',
    idealFor: 'Profissionais autônomos, clínicas, consultorias e prestadores de serviços em geral.',
    features: [
      'Copywriting persuasivo focado em faturamento',
      'Opção de entrega expressa no mesmo dia (24h)',
      'Botões de WhatsApp estratégicos em pontos de alta conversão',
      'Carregamento cirúrgico em menos de 1 segundo',
      'Configuração pronta para Meta Pixel e Google Analytics',
      '100% responsivo e otimizado para celulares'
    ]
  },
  {
    id: 'site-institucional',
    budgetIndex: 'Orçamento 02',
    title: 'Site Institucional de Autoridade',
    category: 'institucional',
    categoryLabel: 'Presença Corporativa',
    shortDescription: 'Ecossistema corporativo completo para posicionar sua empresa como referência absoluta e aumentar o valor das suas propostas.',
    fullDescription: 'Seus clientes pesquisam sua empresa antes de fechar contrato. Criamos um ecossistema digital que transmite seriedade, segurança jurídica e prestígio, elevando seu ticket médio.',
    deliveryTime: '2 a 4 dias úteis',
    highlightBadge: 'Máxima Autoridade',
    idealFor: 'Empresas B2B, escritórios de advocacia, clínicas, engenharia e serviços corporativos.',
    features: [
      'Design corporativo exclusivo e alinhado à sua marca',
      'Seções completas: Quem Somos, Serviços, Diferenciais e Contato',
      'Otimização avançada de SEO para busca no Google',
      'Formulário institucional com envio para e-mail e WhatsApp',
      'Certificado de Segurança SSL e adequação LGPD',
      'Carregamento veloz e adaptabilidade total a qualquer tela'
    ]
  },
  {
    id: 'loja-produtos',
    budgetIndex: 'Orçamento 03',
    title: 'Catálogo & Loja de Produtos Gerais',
    category: 'catalogo',
    categoryLabel: 'Venda de Produtos',
    shortDescription: 'Vitrine digital moderna para expor seus produtos com pedidos fechados diretamente no seu WhatsApp, livre de comissões.',
    fullDescription: 'Ideal para empresas que vendem produtos físicos ou digitais de nichos gerais e desejam um canal proprietário limpo, rápido e sem complicações operacionais.',
    deliveryTime: '2 a 4 dias úteis',
    highlightBadge: 'Produtos Gerais',
    idealFor: 'Marcas de produtos em geral, distribuidores, varejo, cosméticos, moda e utilidades.',
    features: [
      'Vitrine interativa de produtos com fotos em alta definição',
      'Botão de pedido direto no WhatsApp por produto com mensagem pronta',
      'Categorização organizada por linhas e nichos gerais',
      'Sem cobrança de porcentagens ou taxas sobre suas vendas',
      'Velocidade máxima para o cliente comprar em poucos cliques',
      'Visual moderno e ultra-otimizado para smartphones'
    ]
  }
];

export interface ProjectItem {
  id: string;
  title: string;
  niche: string;
  client: string;
  type: string;
  metric: string;
  metricLabel: string;
  description: string;
  image: string;
  tags: string[];
  featuresDelivered: string[];
}

export const PORTFOLIO_DATA: ProjectItem[] = [
  {
    id: 'aurora-medical',
    title: 'Aurora Medical & Estética Integrada',
    niche: 'Saúde, Clínicas & Bem-Estar',
    client: 'Clínica Aurora Estética',
    type: 'Landing Page de Alta Conversão',
    metric: '+185%',
    metricLabel: 'Contatos qualificados no WhatsApp em 30 dias',
    description: 'Desenvolvimento de landing page de luxo para clínica de estética avançada e cirurgia plástica. Foco em autoridade médica, transmissão de confiança e agendamentos diretos.',
    image: '/src/assets/images/portfolio_project_clinic_1793022701763.jpg',
    tags: ['Clínica Médica', 'Alto Padrão', 'Tráfego Pago', 'Agendamento WhatsApp'],
    featuresDelivered: [
      'Design em tons sóbrios e acabamento premium',
      'Seção de antes e depois com conformidade ética',
      'Carregamento em 0.6s em redes 4G/5G',
      'Botões de agendamento setorizados por procedimento'
    ]
  },
  {
    id: 'aether-life',
    title: 'Aether Life - Produtos & Estilo de Vida',
    niche: 'Varejo & Produtos em Geral',
    client: 'Aether Life Brasil',
    type: 'Catálogo de Produtos & Loja Rápida',
    metric: '+68%',
    metricLabel: 'Aumento na taxa de conversão direta',
    description: 'Catálogo digital moderno para marca de produtos de bem-estar e casa. Interface fluida que guia o cliente desde a vitrine de produtos até a finalização ágil no WhatsApp.',
    image: '/src/assets/images/portfolio_project_ecommerce_1793022701544.jpg',
    tags: ['E-commerce', 'Produtos Gerais', 'Checkout WhatsApp', 'Alta Velocidade'],
    featuresDelivered: [
      'Grid de produtos responsivo com zoom de imagem',
      'Botão de pedido direto com mensagem pré-formatada',
      'Banner promocional dinâmico de frete grátis',
      'Integração com catálogo de fotos e variações'
    ]
  },
  {
    id: 'aurum-advocacia',
    title: 'Aurum & Co. Consultoria & Advocacia',
    niche: 'Serviços Corporativos & B2B',
    client: 'Aurum & Co. Advogados',
    type: 'Site Institucional de Prestígio',
    metric: '10x',
    metricLabel: 'Retorno sobre investimento em novos contratos B2B',
    description: 'Site institucional corporativo para escritório de assessoria jurídica e consultoria para empresas. Transmite solidez institucional e atrai clientes corporativos de alto faturamento.',
    image: '/src/assets/images/portfolio_project_corporate_1793022701861.jpg',
    tags: ['Advocacia', 'Consultoria B2B', 'Autoridade Máxima', 'SEO Google'],
    featuresDelivered: [
      'Apresentação de áreas de atuação e sócios',
      'Formulário confidencial para análise de casos',
      'Otimização para busca orgânica regional',
      'Design em modo dark corporativo com tipografia refinada'
    ]
  }
];

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  company: string;
  city: string;
  avatarText: string;
  rating: number;
  highlight: string;
  quote: string;
  impactResult: string;
}

export const TESTIMONIALS_DATA: TestimonialItem[] = [
  {
    id: 'dep-1',
    name: 'Dr. Rodrigo Silveira',
    role: 'Diretor Clínico',
    company: 'Silveira Medicina & Estética',
    city: 'São Paulo, SP',
    avatarText: 'RS',
    rating: 5,
    highlight: 'Dobramos os agendamentos particulares',
    quote: 'Em menos de um mês com a nova landing page da Brenda No Seu Studio, nossos agendamentos no WhatsApp simplesmente dobraram. O design transmite tanto profissionalismo que os pacientes chegam sem questionar o valor da consulta.',
    impactResult: '+110% no faturamento de procedimentos'
  },
  {
    id: 'dep-2',
    name: 'Camila Vasconcelos',
    role: 'Fundadora & Head de Produto',
    company: 'Aether Home & Bem-Estar',
    city: 'Curitiba, PR',
    avatarText: 'CV',
    rating: 5,
    highlight: 'Entrega no mesmo dia com qualidade impecável',
    quote: 'Nós tínhamos uma campanha de lançamento programada e nosso fornecedor anterior nos deixou na mão. A Brenda assumiu o projeto no pacote express e colocou o site no ar no mesmo dia! As vendas começaram na mesma noite.',
    impactResult: 'Site entregue em 8 horas operando 100%'
  },
  {
    id: 'dep-3',
    name: 'Dr. Eduardo Guimarães',
    role: 'Sócio Gestor',
    company: 'Guimarães & Associados',
    city: 'Rio de Janeiro, RJ',
    avatarText: 'EG',
    rating: 5,
    highlight: 'A autoridade que faltava para fechar grandes contratos',
    quote: 'Nosso antigo site parecia um modelo genérico dos anos 2010. A Brenda redesenhou tudo com uma elegância que impressiona nossos clientes corporativos. A taxa de fechamento após visitarem o site aumentou drasticamente.',
    impactResult: '+140% em propostas corporativas aceitas'
  },
  {
    id: 'dep-4',
    name: 'Marcos Tanaka',
    role: 'Diretor Geral',
    company: 'Tanaka Equipamentos & Serviços',
    city: 'Campinas, SP',
    avatarText: 'MT',
    rating: 5,
    highlight: 'Atendimento humanizado e foco em negócios',
    quote: 'A maioria dos desenvolvedores só quer saber de código. A Brenda entende de negócios e faturamento: ela pensou em onde o cliente clicaria para pedir orçamento. Recomendo de olhos fechados.',
    impactResult: 'Custo por lead reduzido em 42%'
  }
];

export const FAQ_DATA = [
  {
    question: 'Como funciona a entrega no mesmo dia?',
    answer: 'Temos um processo otimizado e focado. Ao contratar a opção de entrega expressa, você preenche um breve roteiro com os dados da sua empresa e fotos dos seus serviços ou produtos. Nós trabalhamos em fluxo prioritário contínuo e disponibilizamos a primeira versão online e funcional em até 24 horas.'
  },
  {
    question: 'Por que o foco é em empresas que querem aumentar faturamento?',
    answer: 'Um site bonito que não gera contatos é apenas um enfeite digital. Nossos projetos são arquitetados para direcionar o visitante até o botão do seu WhatsApp com o menor atrito possível, utilizando gatilhos de autoridade, prova social e clareza de proposta.'
  },
  {
    question: 'Vocês atendem quais nichos de mercado?',
    answer: 'Somos especializados em sites para serviços e produtos gerais: clínicas, advogados, consultores, prestadores de serviços técnicos, lojas e distribuidoras de produtos físicos, cursos, profissionais autônomos e empresas locais de todo o Brasil.'
  },
  {
    question: 'O site funciona perfeitamente no celular?',
    answer: 'Sim, 100%! Mais de 80% do tráfego atual navega via smartphones. Desenvolvemos com metodologia mobile-first, garantindo carregamento ultrarrápido, botões de toque acessíveis e visual impecável em qualquer tela.'
  },
  {
    question: 'Como é feito o suporte e após a entrega?',
    answer: 'Você não fica desamparado após o lançamento. Você terá suporte direto pelo WhatsApp para tirar dúvidas e realizar eventuais ajustes para garantir que tudo funcione com excelência.'
  }
];
