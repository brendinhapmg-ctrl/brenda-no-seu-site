import React, { useState } from 'react';
import { MessageCircle, X, Sparkles, Send } from 'lucide-react';
import { STUDIO_CONFIG, getWhatsAppLink } from '../data/studioData';

export const FloatingWhatsApp: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [customMsg, setCustomMsg] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    const finalMsg = customMsg.trim() || 'Olá Brenda! Gostaria de um orçamento para a criação de um site para minha empresa.';
    window.open(getWhatsAppLink(finalMsg), '_blank', 'noopener,noreferrer');
    setIsOpen(false);
    setCustomMsg('');
  };

  return (
    <aside aria-label="Atendimento via WhatsApp" className="fixed bottom-5 right-5 z-40 flex flex-col items-end">
      
      {/* Pop-up dialog when clicked */}
      {isOpen && (
        <div className="mb-3 w-80 sm:w-88 rounded-2xl bg-[#14040e] border border-[#db58ff]/30 shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-3 duration-200">
          
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-[#1f0617] to-[#0c0817] border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#db58ff] to-[#0099b9] p-[1px]">
                  <div className="w-full h-full rounded-full bg-[#090103] flex items-center justify-center text-white font-bold text-xs">
                    BS
                  </div>
                </div>
                {/* Real WhatsApp status indicator */}
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-[#14040e]" />
              </div>

              <div>
                <h4 className="text-sm font-bold text-white leading-tight">
                  Brenda No Seu Studio
                </h4>
                <p className="text-[11px] text-emerald-400 font-medium">
                  Online agora · Resposta rápida
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg text-[#9c8a9e] hover:text-white hover:bg-white/5 transition-colors"
              aria-label="Fechar janela de chat"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Conversation prompt bubble */}
          <div className="p-4 space-y-3 bg-[#0a0104]">
            <div className="p-3 rounded-2xl rounded-tl-sm bg-[#1c0716] border border-[#db58ff]/20 text-xs text-[#d6cad8] leading-relaxed shadow-sm">
              <p className="font-semibold text-white mb-1">Olá! Seja bem-vindo(a)! 👋</p>
              <p>
                Precisa de um site de alto padrão ou quer tirar dúvidas sobre nossa entrega expressa no mesmo dia?
              </p>
            </div>

            <form onSubmit={handleSend} className="space-y-2 pt-1">
              <input
                type="text"
                placeholder="Digite sua dúvida ou ideia de site..."
                value={customMsg}
                onChange={(e) => setCustomMsg(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-[#14040e] border border-white/10 text-white placeholder-[#645566] text-xs focus:outline-none focus:border-[#db58ff]"
              />

              <button
                type="submit"
                className="btn-primary w-full py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-md"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Conversar no WhatsApp Agora</span>
              </button>
            </form>

            <p className="text-[10px] text-[#9c8a9e] text-center font-mono">
              Atendimento oficial: {STUDIO_CONFIG.phoneDisplay}
            </p>
          </div>

        </div>
      )}

      {/* Main Floating Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="group relative flex items-center gap-2.5 px-4 py-3 sm:py-3.5 rounded-full bg-gradient-to-r from-[#db58ff] to-[#0099b9] text-white shadow-xl hover:shadow-[0_0_25px_rgba(219,88,255,0.5)] hover:scale-105 active:scale-95 transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
        aria-label="Falar com Brenda No Seu Studio pelo WhatsApp"
        aria-expanded={isOpen}
      >
        <span className="relative flex items-center justify-center">
          <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 fill-white/20" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full border-2 border-[#090103]" />
        </span>

        <span className="hidden sm:inline text-xs font-bold tracking-tight whitespace-nowrap">
          Solicitar Orçamento
        </span>
      </button>

    </aside>
  );
};
