import React, { useEffect } from 'react';
import { X, Check, MessageCircle, ArrowRight, ExternalLink } from 'lucide-react';
import { ProjectItem, getWhatsAppLink } from '../data/studioData';

interface ProjectModalProps {
  project: ProjectItem | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div 
        className="bg-[#12030b] border border-[#db58ff]/30 rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-[#090103]/80 text-[#d6cad8] hover:text-white border border-white/10 hover:border-[#db58ff]/50 transition-colors"
          aria-label="Fechar detalhes do projeto"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Project Header Image */}
        <div className="relative aspect-[16/9] w-full overflow-hidden rounded-t-2xl bg-[#090103]">
          <img
            src={project.image}
            alt={project.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#12030b] via-transparent to-transparent opacity-90" />
          
          <div className="absolute bottom-4 left-6 right-6">
            <span className="text-xs font-mono text-[#0099b9] uppercase tracking-wider">
              {project.niche}
            </span>
            <h3 id="modal-title" className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
              {project.title}
            </h3>
          </div>
        </div>

        {/* Body content */}
        <div className="p-6 sm:p-8 space-y-6">
          
          {/* Key Metric Card */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-[#1d0717] to-[#0d091a] border border-[#db58ff]/25 flex items-center justify-between">
            <div>
              <p className="text-xs text-[#9c8a9e]">Resultado Comprovado</p>
              <p className="text-xs sm:text-sm font-medium text-white">{project.metricLabel}</p>
            </div>
            <span className="text-2xl sm:text-3xl font-black text-[#db58ff] font-mono tabular-nums">
              {project.metric}
            </span>
          </div>

          <div>
            <h4 className="text-sm font-bold text-white mb-2">Desafio & Estrutura Desenvolvida:</h4>
            <p className="text-sm text-[#d6cad8] leading-relaxed">
              {project.description}
            </p>
          </div>

          {/* Tags */}
          <div>
            <h4 className="text-xs font-semibold text-[#9c8a9e] uppercase tracking-wider mb-2.5">
              Características da Entrega:
            </h4>
            <div className="flex flex-wrap gap-2 text-xs text-[#d6cad8]">
              {project.tags.map((tag, idx) => (
                <span key={idx} className="px-2.5 py-1 rounded-md bg-[#1d0615] border border-white/10 text-white font-medium">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Delivered Features */}
          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-[#9c8a9e] uppercase tracking-wider mb-2">
              Recursos de Conversão Implementados:
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#d6cad8]">
              {project.featuresDelivered.map((feat, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#0099b9] shrink-0" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>

          {/* CTA Footer inside Modal */}
          <div className="pt-6 border-t border-[#db58ff]/15 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-[#9c8a9e]">
              Deseja uma arquitetura similar para a sua empresa?
            </p>

            <a
              href={getWhatsAppLink(`Olá Brenda! Gostei muito do projeto "${project.title}" e gostaria de solicitar um orçamento para criar um site nessa mesma qualidade para a minha empresa.`)}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary w-full sm:w-auto px-6 py-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-lg"
            >
              <MessageCircle className="w-4 h-4 fill-white/20" />
              <span>Solicitar Orçamento Similar no WhatsApp</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>

        </div>
      </div>
    </div>
  );
};
