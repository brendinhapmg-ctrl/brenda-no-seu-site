import React from 'react';
import { MessageCircle, ArrowRight, Zap, Target, TrendingUp, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { STUDIO_CONFIG, getWhatsAppLink } from '../data/studioData';

export const Hero: React.FC = () => {
  return (
    <section id="inicio" className="relative pt-12 pb-20 md:pt-20 md:pb-28 overflow-hidden">
      {/* Ambient background glow */}
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-br from-[#db58ff]/15 via-[#0099b9]/10 to-transparent blur-3xl opacity-70"
      />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Subtle kicker text metadata - Zero-Pill discipline */}
        <div className="flex items-center gap-2 text-xs md:text-sm font-medium text-[#db58ff] tracking-wide mb-5">
          <span className="uppercase font-semibold">Brenda No Seu Studio</span>
          <span aria-hidden="true" className="text-[#9c8a9e]">·</span>
          <span className="text-[#0099b9]">Sites para Serviços e Produtos Gerais</span>
          <span aria-hidden="true" className="text-[#9c8a9e]">·</span>
          <span className="text-[#d6cad8]">Atendimento Brasil</span>
        </div>

        {/* 2-Column Split: Headline & Narrative on Left, Studio Media Showcase on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          <div className="lg:col-span-7 flex flex-col items-start">
            
            {/* Tagline prominent */}
            <p className="text-sm md:text-base font-semibold text-[#0099b9] tracking-normal mb-2 flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#db58ff]" />
              <span>&ldquo;{STUDIO_CONFIG.tagline}&rdquo;</span>
            </p>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-[3.35rem] font-extrabold leading-[1.12] tracking-tight text-white mb-6 text-balance">
              Sites de alto padrão que{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#db58ff] via-[#d06aff] to-[#0099b9]">
                multiplicam o faturamento
              </span>{' '}
              da sua empresa.
            </h1>

            {/* Subtitle oriented to the target audience */}
            <p className="text-base sm:text-lg text-[#d6cad8] leading-relaxed mb-8 max-w-2xl">
              Criamos sites e landing pages profissionais de alta conversão para serviços e produtos em geral. 
              Estrutura moderna, velocidade cirúrgica e o design que posiciona seu negócio com máxima autoridade no mercado.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto mb-10">
              <a
                href={getWhatsAppLink('Olá Brenda! Quero solicitar um orçamento para colocar o site da minha empresa no ar e aumentar minhas vendas.')}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary px-7 py-4 rounded-xl text-sm sm:text-base font-semibold flex items-center justify-center gap-3 shadow-lg group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#db58ff]"
              >
                <MessageCircle className="w-5 h-5 fill-white/20 group-hover:scale-110 transition-transform" />
                <span>Solicitar Orçamento no WhatsApp</span>
                <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
              </a>

              <a
                href="#portfolio"
                className="btn-secondary px-6 py-4 rounded-xl text-sm sm:text-base font-medium flex items-center justify-center gap-2 text-center"
              >
                <span>Ver Portfólio de Projetos</span>
              </a>
            </div>

            {/* Differentiator proof bullets */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm text-[#d6cad8] w-full pt-4 border-t border-[#db58ff]/15">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#db58ff] shrink-0" />
                <span><strong className="text-white">Entrega no mesmo dia</strong> (opção expressa 24h)</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#0099b9] shrink-0" />
                <span><strong className="text-white">Especialista em nichos gerais</strong> (serviços e produtos)</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#0099b9] shrink-0" />
                <span><strong className="text-white">Zero modelos amadores</strong> (design autoral e exclusivo)</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#db58ff] shrink-0" />
                <span><strong className="text-white">WhatsApp estratégico</strong> em todos os pontos de conversão</span>
              </div>
            </div>

          </div>

          {/* Right column: High-Impact Visual Asset Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-[#db58ff]/25 bg-[#14050d] shadow-2xl group">
              <div className="aspect-[16/10] w-full overflow-hidden relative">
                <img
                  src="/src/assets/images/hero_brenda_studio_1793022700124.jpg"
                  alt="Estúdio moderno de criação de sites Brenda No Seu Studio com monitores de alta conversão"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                
                {/* Visual gradient overlay for text readability */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#090103] via-transparent to-transparent opacity-80" />
                
                {/* Floating highlight badge */}
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl backdrop-blur-md bg-[#090103]/85 border border-[#db58ff]/25 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-white">Brenda No Seu Studio</p>
                    <p className="text-[11px] text-[#9c8a9e]">Engenharia de Conversão & Design Premium</p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-[#db58ff] tabular-nums">24h Express</span>
                    <p className="text-[10px] text-[#0099b9]">Disponível</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Background decorative halo */}
            <div 
              aria-hidden="true" 
              className="absolute -bottom-6 -right-6 w-48 h-48 bg-[#0099b9]/20 blur-3xl pointer-events-none"
            />
          </div>

        </div>

        {/* 4-Column Metric Strip below Hero */}
        <div className="mt-16 pt-8 border-t border-[#db58ff]/15 grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8">
          <div className="flex flex-col">
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono tabular-nums">
              Mesmo Dia
            </span>
            <span className="text-xs text-[#9c8a9e] mt-1">Entrega ágil para urgências comerciais</span>
          </div>

          <div className="flex flex-col">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#db58ff] font-mono tabular-nums">
              +100%
            </span>
            <span className="text-xs text-[#9c8a9e] mt-1">Foco direto no aumento de conversão</span>
          </div>

          <div className="flex flex-col">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#0099b9] font-mono tabular-nums">
              &lt; 1.0s
            </span>
            <span className="text-xs text-[#9c8a9e] mt-1">Velocidade ultrarrápida no celular</span>
          </div>

          <div className="flex flex-col">
            <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono tabular-nums">
              100%
            </span>
            <span className="text-xs text-[#9c8a9e] mt-1">Suporte humanizado no WhatsApp</span>
          </div>
        </div>

      </div>
    </section>
  );
};
