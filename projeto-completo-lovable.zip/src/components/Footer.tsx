import React from 'react';
import { MessageCircle, Instagram, ArrowUpRight, ShieldCheck, Heart, Sparkles } from 'lucide-react';
import { STUDIO_CONFIG, getWhatsAppLink } from '../data/studioData';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#060002] border-t border-[#db58ff]/15 text-[#d6cad8] text-xs pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-12 pb-14 border-b border-white/5">
          
          {/* Brand info */}
          <div className="lg:col-span-5 flex flex-col items-start">
            <a href="#inicio" className="flex items-center gap-2.5 text-base font-bold text-white mb-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#db58ff] to-[#0099b9] flex items-center justify-center p-[1px]">
                <div className="w-full h-full bg-[#090103] rounded-[7px] flex items-center justify-center">
                  <span className="text-transparent bg-clip-text bg-gradient-to-tr from-[#db58ff] to-[#0099b9] font-black text-xs">
                    BS
                  </span>
                </div>
              </div>
              <span>
                Brenda <span className="text-[#db58ff]">No Seu Studio</span>
              </span>
            </a>

            <p className="text-[#9c8a9e] text-xs leading-relaxed max-w-sm mb-4">
              Criação de sites de alto padrão e alta conversão para serviços e produtos em geral. Transformamos visitantes em clientes faturando todos os dias.
            </p>

            <p className="text-xs font-semibold text-[#0099b9] mb-6">
              &ldquo;{STUDIO_CONFIG.tagline}&rdquo;
            </p>

            {/* Social links */}
            <div className="flex items-center gap-3">
              <a
                href={STUDIO_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#14040e] border border-[#db58ff]/20 text-white hover:text-[#db58ff] transition-colors"
                aria-label="Instagram Brenda No Seu Studio"
              >
                <Instagram className="w-3.5 h-3.5 text-[#db58ff]" />
                <span>{STUDIO_CONFIG.instagramHandle}</span>
                <ArrowUpRight className="w-3 h-3 text-[#9c8a9e]" />
              </a>

              <a
                href={getWhatsAppLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#14040e] border border-[#0099b9]/25 text-white hover:text-[#0099b9] transition-colors"
                aria-label="WhatsApp Brenda No Seu Studio"
              >
                <MessageCircle className="w-3.5 h-3.5 text-[#0099b9]" />
                <span>{STUDIO_CONFIG.phoneDisplay}</span>
              </a>
            </div>
          </div>

          {/* Quick Nav */}
          <div className="lg:col-span-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 font-mono">
              Navegação
            </h4>
            <ul className="space-y-2.5">
              <li>
                <a href="#inicio" className="hover:text-white transition-colors">Início</a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-white transition-colors">Sobre / Quem Sou</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Serviços Oferecidos</a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-white transition-colors">Portfólio & Casos</a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-white transition-colors">Depoimentos de Clientes</a>
              </li>
              <li>
                <a href="#contato" className="hover:text-white transition-colors">Solicitar Orçamento</a>
              </li>
            </ul>
          </div>

          {/* Services Quicklist */}
          <div className="lg:col-span-4">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 font-mono">
              Especialidades
            </h4>
            <ul className="space-y-2.5 text-xs text-[#9c8a9e]">
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#db58ff]" />
                <span>Landing Pages de Alta Conversão</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#0099b9]" />
                <span>Sites Institucionais de Autoridade</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#db58ff]" />
                <span>Lojas & Catálogos para Produtos Gerais</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#0099b9]" />
                <span>Entrega Expressa no Mesmo Dia (24h)</span>
              </li>
              <li className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#db58ff]" />
                <span>Redesign Estratégico & Mobile Speed</span>
              </li>
            </ul>

            <div className="mt-5 p-3 rounded-xl bg-[#14040e] border border-white/5 text-[11px] text-[#9c8a9e]">
              Atendemos todo o território nacional via atendimento digital humanizado.
            </div>
          </div>

        </div>

        {/* Bottom copyright row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#645566]">
          <p>
            © {new Date().getFullYear()} Brenda No Seu Studio. Todos os direitos reservados.
          </p>

          <p className="flex items-center gap-1">
            <span>Desenvolvido com foco em alta conversão</span>
            <span aria-hidden="true">·</span>
            <span>Brasil</span>
          </p>
        </div>

      </div>
    </footer>
  );
};
