import React, { useState } from 'react';
import { Eye, ArrowUpRight, CheckCircle2, TrendingUp, Sparkles, MessageCircle } from 'lucide-react';
import { PORTFOLIO_DATA, ProjectItem, getWhatsAppLink } from '../data/studioData';
import { ProjectModal } from './ProjectModal';

export const Portfolio: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  return (
    <section id="portfolio" className="py-20 md:py-28 bg-[#0d0107] relative overflow-hidden border-t border-[#db58ff]/15">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#db58ff] uppercase tracking-wider mb-2">
              <span>03</span>
              <span aria-hidden="true" className="text-[#9c8a9e]">·</span>
              <span>Casos de Sucesso & Portfólio</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight text-balance">
              Projetos que colocam sua empresa no topo da decisão do cliente.
            </h2>
            <p className="text-base text-[#d6cad8] mt-3">
              Veja alguns dos sites desenvolvidos pela Brenda No Seu Studio em diferentes nichos de mercado e os impactos medidos em faturamento.
            </p>
          </div>

          <div className="text-xs text-[#9c8a9e] flex items-center gap-2 self-start md:self-auto font-mono">
            <span className="w-2 h-2 rounded-full bg-[#0099b9]" />
            <span>Métricas reais validadas por clientes</span>
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {PORTFOLIO_DATA.map((project) => (
            <div
              key={project.id}
              className="bg-studio-card rounded-2xl overflow-hidden flex flex-col justify-between group transition-all duration-300 hover:border-[#db58ff]/50"
            >
              <div>
                {/* Visual Image Slot */}
                <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#090103] cursor-pointer"
                  onClick={() => setSelectedProject(project)}
                >
                  <img
                    src={project.image}
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#180612] via-transparent to-transparent opacity-80" />

                  {/* Impact metric float tag */}
                  <div className="absolute top-4 left-4 py-1.5 px-3 rounded-lg backdrop-blur-md bg-[#090103]/90 border border-[#db58ff]/30 text-xs font-bold text-white flex items-center gap-2">
                    <TrendingUp className="w-3.5 h-3.5 text-[#db58ff]" />
                    <span className="text-[#db58ff] font-mono tabular-nums">{project.metric}</span>
                    <span className="text-[11px] text-[#d6cad8] font-normal">resultado</span>
                  </div>

                  {/* Hover visual affordance */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 backdrop-blur-[2px]">
                    <span className="px-4 py-2 rounded-xl bg-white text-[#090103] text-xs font-bold flex items-center gap-1.5 shadow-lg">
                      <Eye className="w-4 h-4" />
                      <span>Ver Detalhes do Projeto</span>
                    </span>
                  </div>
                </div>

                {/* Content info */}
                <div className="p-6">
                  {/* Category & Niche */}
                  <div className="flex items-center justify-between text-xs text-[#9c8a9e] mb-2 font-mono">
                    <span className="text-[#0099b9]">{project.niche}</span>
                    <span>{project.type.split(' ')[0]}</span>
                  </div>

                  {/* Title */}
                  <h3 
                    onClick={() => setSelectedProject(project)}
                    className="text-lg font-bold text-white mb-2 cursor-pointer group-hover:text-[#db58ff] transition-colors"
                  >
                    {project.title}
                  </h3>

                  {/* Description */}
                  <p className="text-xs sm:text-sm text-[#d6cad8] leading-relaxed mb-4 line-clamp-3">
                    {project.description}
                  </p>

                  {/* Metric statement */}
                  <div className="p-3 rounded-lg bg-[#0e0208] border border-white/5 text-xs text-[#d6cad8] mb-4">
                    <span className="font-semibold text-white">{project.metric}</span> {project.metricLabel}
                  </div>
                </div>
              </div>

              {/* Card Footer actions */}
              <div className="px-6 pb-6 pt-2 flex items-center gap-2">
                <button
                  onClick={() => setSelectedProject(project)}
                  className="flex-1 py-2.5 px-3 rounded-xl btn-secondary text-xs font-medium flex items-center justify-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Ver Detalhes</span>
                </button>

                <a
                  href={getWhatsAppLink(`Olá Brenda! Vi o projeto "${project.title}" no seu portfólio e gostaria de um orçamento para um site parecido.`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#db58ff]/20 to-[#0099b9]/20 hover:from-[#db58ff] hover:to-[#0099b9] text-white border border-[#db58ff]/30 text-xs font-semibold flex items-center justify-center gap-1 transition-all"
                  title="Orçar site similar"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Quero Igual</span>
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Callout box */}
        <div className="mt-14 text-center">
          <p className="text-sm text-[#d6cad8] mb-4">
            Procurando uma estrutura específica para o seu modelo de vendas?
          </p>
          <a
            href={getWhatsAppLink('Olá Brenda! Quero conversar sobre um projeto de site para a minha empresa e receber referências do meu nicho.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#db58ff] hover:text-[#e57cff] transition-colors pb-1 border-b border-[#db58ff]/40 hover:border-[#db58ff]"
          >
            <span>Solicitar referências exclusivas do seu segmento no WhatsApp</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

      </div>

      {/* Modal instance */}
      <ProjectModal 
        project={selectedProject} 
        onClose={() => setSelectedProject(null)} 
      />
    </section>
  );
};
