import React from 'react';
import { 
  Check, 
  ArrowRight, 
  Clock, 
  Sparkles, 
  MessageCircle,
  Zap,
  Building2,
  ShoppingBag
} from 'lucide-react';
import { SERVICES_DATA, getWhatsAppLink } from '../data/studioData';

export const Services: React.FC = () => {
  return (
    <section id="servicos" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#0099b9] uppercase tracking-wider mb-2">
            <span>02</span>
            <span aria-hidden="true" className="text-[#9c8a9e]">·</span>
            <span>Serviços Oferecidos</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight text-balance">
            Criação de sites para serviços e produtos gerais.
          </h2>
          <p className="text-base text-[#d6cad8] mt-4 max-w-2xl mx-auto">
            Desenvolvemos estruturas estratégicas sob medida para empresas que querem aumentar o faturamento e ser vistas com máxima autoridade.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {SERVICES_DATA.map((service, index) => {
            const isFeatured = index === 0;

            return (
              <div
                key={service.id}
                className={`bg-studio-card rounded-2xl p-7 sm:p-8 flex flex-col justify-between relative group transition-all duration-300 ${
                  isFeatured 
                    ? 'border-[#db58ff]/40 bg-[#1a0615] shadow-[0_0_40px_rgba(219,88,255,0.15)] ring-1 ring-[#db58ff]/30' 
                    : 'hover:border-[#0099b9]/40'
                }`}
              >
                <div>
                  {/* Category & Badge */}
                  <div className="flex items-center justify-between text-xs text-[#9c8a9e] mb-4">
                    <span className="font-mono text-[#0099b9] font-semibold tracking-wider uppercase">
                      {service.categoryLabel}
                    </span>
                    {service.highlightBadge && (
                      <span className={`text-[11px] font-bold tracking-wide px-2.5 py-0.5 rounded-full ${
                        isFeatured 
                          ? 'bg-[#db58ff]/20 text-[#db58ff] border border-[#db58ff]/30' 
                          : 'bg-[#0099b9]/20 text-[#0099b9] border border-[#0099b9]/30'
                      }`}>
                        ★ {service.highlightBadge}
                      </span>
                    )}
                  </div>

                  {/* Icon indicator */}
                  <div className="mb-4">
                    {index === 0 && (
                      <div className="w-10 h-10 rounded-xl bg-[#db58ff]/15 text-[#db58ff] flex items-center justify-center">
                        <Zap className="w-5 h-5" />
                      </div>
                    )}
                    {index === 1 && (
                      <div className="w-10 h-10 rounded-xl bg-[#0099b9]/15 text-[#0099b9] flex items-center justify-center">
                        <Building2 className="w-5 h-5" />
                      </div>
                    )}
                    {index === 2 && (
                      <div className="w-10 h-10 rounded-xl bg-purple-500/15 text-purple-300 flex items-center justify-center">
                        <ShoppingBag className="w-5 h-5" />
                      </div>
                    )}
                  </div>

                  {/* Title */}
                  <h3 className="text-2xl font-bold text-white mb-3">
                    {service.title}
                  </h3>

                  {/* Short Description */}
                  <p className="text-sm text-[#d6cad8] leading-relaxed mb-6">
                    {service.shortDescription}
                  </p>

                  {/* Delivery time strip */}
                  <div className="flex items-center gap-2 py-2.5 px-3.5 rounded-xl bg-[#0e0208] border border-white/5 text-xs text-[#d6cad8] mb-6">
                    <Clock className="w-4 h-4 text-[#db58ff] shrink-0" />
                    <span>Prazo: <strong className="text-white">{service.deliveryTime}</strong></span>
                  </div>

                  {/* Features list */}
                  <div className="space-y-3 mb-8">
                    <p className="text-xs font-semibold text-white uppercase tracking-wider">
                      O que está incluso na entrega:
                    </p>
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs text-[#d6cad8]">
                        <Check className="w-4 h-4 text-[#0099b9] shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>

                  {/* Recommended for */}
                  <div className="p-3 rounded-lg bg-[#0a0104] border border-white/5 text-xs text-[#9c8a9e] mb-8">
                    <span className="text-white font-medium">Ideal para:</span> {service.idealFor}
                  </div>
                </div>

                {/* Card Action Button */}
                <div className="pt-4 border-t border-white/5">
                  <a
                    href={getWhatsAppLink(`Olá Brenda! Gostaria de um orçamento para criação de: *${service.title}* para a minha empresa. Poderia me passar os detalhes?`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-full py-3.5 px-4 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-all group/btn shadow-md ${
                      isFeatured ? 'btn-primary' : 'btn-secondary hover:btn-primary'
                    }`}
                  >
                    <MessageCircle className="w-4 h-4 fill-white/20" />
                    <span>Solicitar Orçamento no WhatsApp</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Reassurance Banner */}
        <div className="mt-14 p-8 rounded-2xl bg-gradient-to-r from-[#170512] to-[#0c0514] border border-[#db58ff]/25 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="max-w-xl">
            <h4 className="text-lg font-bold text-white mb-1">
              Quer uma proposta sob medida para o momento da sua empresa?
            </h4>
            <p className="text-sm text-[#d6cad8]">
              Fale diretamente com a Brenda no WhatsApp. Analisamos seu segmento e desenhamos a presença digital ideal para o seu negócio.
            </p>
          </div>
          <a
            href={getWhatsAppLink('Olá Brenda! Gostaria de conversar sobre um projeto de site para a minha empresa.')}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary px-6 py-3.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            <MessageCircle className="w-4 h-4 fill-white/20" />
            <span>Falar com a Brenda no WhatsApp</span>
          </a>
        </div>

      </div>
    </section>
  );
};
