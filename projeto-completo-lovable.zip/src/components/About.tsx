import React from 'react';
import { Sparkles, Layers, ShieldCheck, HeartHandshake, ArrowRight, MessageCircle } from 'lucide-react';
import { STUDIO_CONFIG, getWhatsAppLink } from '../data/studioData';

export const About: React.FC = () => {
  return (
    <section id="sobre" className="py-20 md:py-28 bg-[#11030b] relative overflow-hidden border-y border-[#db58ff]/15">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#db58ff] uppercase tracking-wider mb-2">
            <span>01</span>
            <span aria-hidden="true" className="text-[#9c8a9e]">·</span>
            <span>Quem Somos & Nossa História</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight text-balance">
            Criatividade e tecnologia a serviço da autoridade do seu negócio.
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Founder Photo & Studio Atmosphere */}
          <div className="lg:col-span-5">
            <div className="relative">
              <div className="rounded-2xl overflow-hidden border border-[#db58ff]/30 shadow-2xl bg-[#190614]">
                <div className="aspect-[4/5] sm:aspect-[4/3] lg:aspect-[4/5] relative">
                  <img
                    src="/src/assets/images/about_brenda_creative_1793022700256.jpg"
                    alt="Brenda, fundadora da Brenda No Seu Studio, no estúdio de tecnologia e web design"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#090103] via-transparent to-transparent opacity-85" />
                  
                  {/* Subtle caption */}
                  <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl backdrop-blur-md bg-[#090103]/85 border border-white/10">
                    <p className="text-sm font-bold text-white">Brenda</p>
                    <p className="text-xs text-[#d6cad8]">Fundadora & Especialista em Presença Digital</p>
                    <p className="text-[11px] text-[#db58ff] mt-1 font-mono">Brenda No Seu Studio</p>
                  </div>
                </div>
              </div>

              {/* Decorative accent behind */}
              <div 
                aria-hidden="true" 
                className="absolute -top-4 -left-4 w-32 h-32 bg-[#db58ff]/20 rounded-full blur-2xl pointer-events-none"
              />
            </div>
          </div>

          {/* Right Column: The Core Manifesto & Story */}
          <div className="lg:col-span-7 flex flex-col items-start">
            
            {/* The Exact Quote from user prompt */}
            <blockquote className="p-6 rounded-2xl bg-[#180612] border border-[#db58ff]/25 text-white text-lg sm:text-xl font-medium leading-relaxed mb-8 shadow-lg">
              <p className="text-transparent bg-clip-text bg-gradient-to-r from-white via-[#f0d4ff] to-[#d4f6ff]">
                &ldquo;Juntei duas das minhas paixões: criatividade e tecnologia. Hoje, já somos uma empresa que ajuda você a ser visto com autoridade, mas tudo começou com uma ideia. Agora é a sua vez: você entra com a ideia, e nós, com a sua visibilidade.&rdquo; 🚀
              </p>
            </blockquote>

            <p className="text-base text-[#d6cad8] leading-relaxed mb-6">
              No <strong className="text-white">Brenda No Seu Studio</strong>, acreditamos que nenhuma empresa séria deve perder clientes simplesmente porque seu site parece amador ou demorado para carregar.
            </p>

            <p className="text-base text-[#d6cad8] leading-relaxed mb-8">
              Atuamos na venda e criação de sites para serviços e produtos gerais em todo o Brasil. Combinamos design refinado, psicologia de compra e código de alta performance para garantir que quem visita sua página tome uma única decisão óbvia: <span className="text-white font-semibold">chamar a sua equipe no WhatsApp</span>.
            </p>

            {/* Core Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full mb-8">
              <div className="p-4 rounded-xl bg-[#180612] border border-[#db58ff]/15">
                <div className="flex items-center gap-2 text-white font-semibold text-sm mb-1.5">
                  <Sparkles className="w-4 h-4 text-[#db58ff]" />
                  <span>Design Exclusivo e Autoral</span>
                </div>
                <p className="text-xs text-[#9c8a9e] leading-relaxed">
                  Sem templates batidos. Criamos uma identidade digital personalizada que coloca sua empresa em outro patamar de percepção de valor.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#180612] border border-[#0099b9]/20">
                <div className="flex items-center gap-2 text-white font-semibold text-sm mb-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#0099b9]" />
                  <span>Foco em Faturamento Real</span>
                </div>
                <p className="text-xs text-[#9c8a9e] leading-relaxed">
                  Cada botão, texto e imagem são pensados estrategicamente para guiar o cliente à conversão e gerar orçamentos qualificados.
                </p>
              </div>
            </div>

            {/* Direct action button */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <a
                href={getWhatsAppLink('Olá Brenda! Li a história do studio e quero transformar minha ideia em um site com autoridade.')}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary px-6 py-3.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 shadow-md"
              >
                <MessageCircle className="w-4 h-4 fill-white/20" />
                <span>Conversar Diretamente com a Brenda</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <a
                href={STUDIO_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-secondary px-5 py-3.5 rounded-xl text-xs font-medium text-center"
              >
                Conhecer bastidores no Instagram
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
