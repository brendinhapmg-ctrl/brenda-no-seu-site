import React, { useState } from 'react';
import { MessageCircle, Menu, X, ArrowUpRight, Sparkles } from 'lucide-react';
import { STUDIO_CONFIG, getWhatsAppLink } from '../data/studioData';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Sobre', href: '#sobre' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Portfólio', href: '#portfolio' },
    { label: 'Depoimentos', href: '#depoimentos' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-[#090103]/85 border-b border-[#db58ff]/15 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        
        {/* Zone 1: Single text element wordmark */}
        <a 
          href="#inicio" 
          className="flex items-center gap-3 text-lg sm:text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#db58ff]"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#db58ff] to-[#0099b9] flex items-center justify-center p-[1px] shadow-sm group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-[#090103] rounded-[11px] flex items-center justify-center">
              <span className="text-transparent bg-clip-text bg-gradient-to-tr from-[#db58ff] to-[#0099b9] font-black text-sm tracking-wider">
                BS
              </span>
            </div>
          </div>
          <span className="font-semibold text-white tracking-tight">
            Brenda <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#db58ff] to-[#0099b9]">No Seu Studio</span>
          </span>
        </a>

        {/* Zone 2: 5 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#d6cad8]">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="hover:text-white transition-colors relative py-1 hover:after:w-full after:w-0 after:h-[2px] after:absolute after:bottom-0 after:left-0 after:bg-gradient-to-r after:from-[#db58ff] after:to-[#0099b9] after:transition-all after:duration-200 whitespace-nowrap shrink-0"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: 1 primary action + Instagram icon */}
        <div className="hidden lg:flex items-center gap-4 shrink-0">
          <a
            href={STUDIO_CONFIG.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-[#9c8a9e] hover:text-[#db58ff] transition-colors flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#db58ff]/15 hover:border-[#db58ff]/40 bg-[#14050d]"
            title="Siga no Instagram @brendanoseustudio"
            aria-label="Perfil do Instagram de Brenda No Seu Studio"
          >
            <span className="text-[11px]">@brendanoseustudio</span>
            <ArrowUpRight className="w-3 h-3 text-[#db58ff]" />
          </a>

          <a
            href={getWhatsAppLink('Olá Brenda! Gostaria de solicitar um orçamento para o site da minha empresa.')}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 whitespace-nowrap shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#db58ff]"
          >
            <MessageCircle className="w-4 h-4 fill-white/20" />
            <span>Orçamento no WhatsApp</span>
          </a>
        </div>

        {/* Mobile menu hamburger toggle */}
        <div className="flex md:hidden items-center gap-2">
          <a
            href={getWhatsAppLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-lg bg-gradient-to-r from-[#db58ff] to-[#0099b9] text-white"
            aria-label="Chamar Brenda no WhatsApp"
          >
            <MessageCircle className="w-5 h-5" />
          </a>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-white hover:bg-white/5 border border-white/10"
            aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu de navegação'}
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-[#db58ff]/20 bg-[#0e0207]/95 backdrop-blur-2xl px-6 py-6 animate-in slide-in-from-top-2">
          <nav className="flex flex-col gap-4 text-base font-medium">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="py-2 text-[#d6cad8] hover:text-white border-b border-white/5 flex items-center justify-between"
              >
                <span>{link.label}</span>
                <span className="text-xs text-[#9c8a9e]">Ir</span>
              </a>
            ))}
            
            <div className="pt-4 flex flex-col gap-3">
              <a
                href={getWhatsAppLink('Olá Brenda! Vim pelo site no celular e quero um orçamento.')}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                className="btn-primary w-full py-3 rounded-xl text-center text-sm font-semibold flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Solicitar Orçamento no WhatsApp</span>
              </a>

              <a
                href={STUDIO_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 rounded-xl border border-[#db58ff]/20 text-[#d6cad8] text-xs font-medium text-center flex items-center justify-center gap-1.5"
              >
                <span>Instagram: {STUDIO_CONFIG.instagramHandle}</span>
                <ArrowUpRight className="w-3.5 h-3.5 text-[#db58ff]" />
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
