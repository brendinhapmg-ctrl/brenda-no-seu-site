import React, { useState } from 'react';
import { 
  MessageCircle, 
  Send, 
  Sparkles, 
  Clock, 
  ShieldCheck, 
  Phone, 
  Instagram, 
  MapPin, 
  CheckCircle2,
  Copy,
  Check
} from 'lucide-react';
import { STUDIO_CONFIG, getWhatsAppLink } from '../data/studioData';

export const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState({
    nome: '',
    whatsapp: '',
    empresa: '',
    nicho: '',
    tipoSite: 'Landing Page de Alta Conversão',
    urgencia: 'Normal (3 a 5 dias úteis)',
    mensagem: ''
  });

  const [submittedOnline, setSubmittedOnline] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);

  const formatPhone = (val: string) => {
    const raw = val.replace(/\D/g, '').slice(0, 11);
    if (raw.length <= 2) return raw;
    if (raw.length <= 7) return `(${raw.slice(0, 2)}) ${raw.slice(2)}`;
    return `(${raw.slice(0, 2)}) ${raw.slice(2, 7)}-${raw.slice(7)}`;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, whatsapp: formatPhone(e.target.value) });
  };

  const generateWhatsAppMessage = () => {
    return (
      `*Solicitação de Orçamento - Brenda No Seu Studio*\n\n` +
      `*Nome:* ${formData.nome || 'Não informado'}\n` +
      `*WhatsApp:* ${formData.whatsapp || 'Não informado'}\n` +
      `*Empresa:* ${formData.empresa || 'Não informado'}\n` +
      `*Nicho / Segmento:* ${formData.nicho || 'Geral'}\n` +
      `*Tipo de Site:* ${formData.tipoSite}\n` +
      `*Prazo Pretendido:* ${formData.urgencia}\n\n` +
      `*Detalhes do Projeto:*\n${formData.mensagem || 'Gostaria de uma proposta personalizada para a minha empresa.'}`
    );
  };

  const handleSubmitWhatsApp = (e: React.FormEvent) => {
    e.preventDefault();
    const msg = generateWhatsAppMessage();
    const url = getWhatsAppLink(msg);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleRegisterOnline = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittedOnline(true);
  };

  const handleCopyPhone = () => {
    navigator.clipboard.writeText('11939071706');
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2000);
  };

  return (
    <section id="contato" className="py-20 md:py-28 relative overflow-hidden bg-[#090103]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-14">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#db58ff] uppercase tracking-wider mb-2">
            <span>05</span>
            <span aria-hidden="true" className="text-[#9c8a9e]">·</span>
            <span>Solicitação de Proposta</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight text-balance">
            Você entra com a ideia, nós entramos com a visibilidade.
          </h2>
          <p className="text-base text-[#d6cad8] mt-3">
            Preencha o formulário para enviar sua demanda diretamente para a Brenda no WhatsApp ou solicite um orçamento detalhado.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Left Column: Form */}
          <div className="lg:col-span-7 bg-[#14040e] border border-[#db58ff]/25 rounded-2xl p-6 sm:p-8 shadow-2xl">
            
            {submittedOnline ? (
              <div className="py-10 text-center space-y-4">
                <div className="w-14 h-14 rounded-full bg-[#db58ff]/20 text-[#db58ff] mx-auto flex items-center justify-center border border-[#db58ff]/40">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-white">
                  Proposta Registrada com Sucesso!
                </h3>
                <p className="text-sm text-[#d6cad8] max-w-md mx-auto">
                  Recebemos suas informações. Para agilizar o atendimento prioritário e receber o orçamento em minutos, confirme no WhatsApp:
                </p>

                <div className="pt-4">
                  <a
                    href={getWhatsAppLink(generateWhatsAppMessage())}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-primary inline-flex items-center gap-2 px-6 py-3.5 rounded-xl text-sm font-semibold"
                  >
                    <MessageCircle className="w-5 h-5 fill-white/20" />
                    <span>Abrir Conversa no WhatsApp Agora</span>
                  </a>
                </div>

                <button
                  onClick={() => setSubmittedOnline(false)}
                  className="text-xs text-[#9c8a9e] hover:text-white block mx-auto pt-2 underline underline-offset-4"
                >
                  Enviar outro projeto
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmitWhatsApp} className="space-y-5">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Nome */}
                  <div>
                    <label className="block text-xs font-semibold text-[#d6cad8] uppercase tracking-wider mb-2">
                      Seu Nome Completo *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Carlos Mendes"
                      value={formData.nome}
                      onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#090103] border border-[#db58ff]/20 text-white placeholder-[#645566] text-sm focus:outline-none focus:border-[#db58ff] transition-colors"
                    />
                  </div>

                  {/* WhatsApp */}
                  <div>
                    <label className="block text-xs font-semibold text-[#d6cad8] uppercase tracking-wider mb-2">
                      Seu WhatsApp (com DDD) *
                    </label>
                    <input
                      type="tel"
                      required
                      placeholder="(11) 99999-9999"
                      value={formData.whatsapp}
                      onChange={handlePhoneChange}
                      className="w-full px-4 py-3 rounded-xl bg-[#090103] border border-[#db58ff]/20 text-white placeholder-[#645566] text-sm focus:outline-none focus:border-[#db58ff] transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Empresa */}
                  <div>
                    <label className="block text-xs font-semibold text-[#d6cad8] uppercase tracking-wider mb-2">
                      Nome da Empresa / Projeto *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Prime Odontologia"
                      value={formData.empresa}
                      onChange={(e) => setFormData({ ...formData, empresa: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#090103] border border-[#db58ff]/20 text-white placeholder-[#645566] text-sm focus:outline-none focus:border-[#db58ff] transition-colors"
                    />
                  </div>

                  {/* Nicho */}
                  <div>
                    <label className="block text-xs font-semibold text-[#d6cad8] uppercase tracking-wider mb-2">
                      Nicho ou Segmento de Atuação
                    </label>
                    <input
                      type="text"
                      placeholder="Ex: Saúde, Advocacia, Varejo, Serviços..."
                      value={formData.nicho}
                      onChange={(e) => setFormData({ ...formData, nicho: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#090103] border border-[#db58ff]/20 text-white placeholder-[#645566] text-sm focus:outline-none focus:border-[#db58ff] transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Tipo de Site */}
                  <div>
                    <label className="block text-xs font-semibold text-[#d6cad8] uppercase tracking-wider mb-2">
                      Estrutura Desejada
                    </label>
                    <select
                      value={formData.tipoSite}
                      onChange={(e) => setFormData({ ...formData, tipoSite: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#090103] border border-[#db58ff]/20 text-white text-sm focus:outline-none focus:border-[#db58ff] transition-colors"
                    >
                      <option value="Landing Page de Alta Conversão">Landing Page de Alta Conversão</option>
                      <option value="Site Institucional de Autoridade">Site Institucional de Autoridade</option>
                      <option value="Catálogo & Loja de Produtos Gerais">Catálogo & Loja de Produtos Gerais</option>
                    </select>
                  </div>

                  {/* Urgência */}
                  <div>
                    <label className="block text-xs font-semibold text-[#d6cad8] uppercase tracking-wider mb-2">
                      Prazo Pretendido
                    </label>
                    <select
                      value={formData.urgencia}
                      onChange={(e) => setFormData({ ...formData, urgencia: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-[#090103] border border-[#db58ff]/20 text-white text-sm focus:outline-none focus:border-[#db58ff] transition-colors"
                    >
                      <option value="Normal (3 a 5 dias úteis)">Normal (3 a 5 dias úteis)</option>
                      <option value="Urgente - Entrega no Mesmo Dia (24h)">⚡ Urgente - Entrega no Mesmo Dia (24h)</option>
                      <option value="Apenas orçando para as próximas semanas">Apenas orçando para as próximas semanas</option>
                    </select>
                  </div>
                </div>

                {/* Mensagem */}
                <div>
                  <label className="block text-xs font-semibold text-[#d6cad8] uppercase tracking-wider mb-2">
                    Conte um pouco da sua ideia ou objetivo de vendas:
                  </label>
                  <textarea
                    rows={3}
                    placeholder="Ex: Preciso de uma landing page para anunciar no Google e receber contatos no WhatsApp todos os dias..."
                    value={formData.mensagem}
                    onChange={(e) => setFormData({ ...formData, mensagem: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-[#090103] border border-[#db58ff]/20 text-white placeholder-[#645566] text-sm focus:outline-none focus:border-[#db58ff] transition-colors resize-none"
                  />
                </div>

                {/* Action Buttons */}
                <div className="pt-2 flex flex-col sm:flex-row gap-3">
                  <button
                    type="submit"
                    className="btn-primary flex-1 py-4 px-6 rounded-xl text-sm font-semibold flex items-center justify-center gap-2.5 shadow-lg group"
                  >
                    <MessageCircle className="w-5 h-5 fill-white/20 group-hover:scale-110 transition-transform" />
                    <span>Enviar e Solicitar no WhatsApp</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleRegisterOnline}
                    className="btn-secondary py-4 px-5 rounded-xl text-xs font-medium"
                  >
                    Registrar Proposta Online
                  </button>
                </div>

                <p className="text-[11px] text-[#9c8a9e] text-center">
                  🔒 Seus dados estão seguros. Não enviamos spam. Atendimento 100% humanizado pela Brenda.
                </p>

              </form>
            )}

          </div>

          {/* Right Column: Direct Contacts & Reassurance */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Direct Contact Cards */}
            <div className="bg-[#14040e] border border-[#db58ff]/20 rounded-2xl p-6 sm:p-7 space-y-6">
              <h3 className="text-lg font-bold text-white">
                Canais Diretos de Atendimento
              </h3>

              {/* WhatsApp Card */}
              <div className="p-4 rounded-xl bg-[#090103] border border-[#db58ff]/15 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#db58ff]/20 text-[#db58ff] flex items-center justify-center">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-[#9c8a9e]">WhatsApp Oficial</p>
                    <p className="text-sm font-bold text-white font-mono">{STUDIO_CONFIG.phoneDisplay}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleCopyPhone}
                  className="p-2 rounded-lg hover:bg-white/5 text-[#d6cad8] hover:text-white transition-colors"
                  title="Copiar número"
                >
                  {copiedPhone ? <Check className="w-4 h-4 text-[#0099b9]" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Instagram Card */}
              <a
                href={STUDIO_CONFIG.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 rounded-xl bg-[#090103] border border-[#db58ff]/15 flex items-center justify-between group hover:border-[#db58ff]/40 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#0099b9]/20 text-[#0099b9] flex items-center justify-center">
                    <Instagram className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-[#9c8a9e]">Instagram Oficial</p>
                    <p className="text-sm font-bold text-white group-hover:text-[#db58ff] transition-colors">
                      {STUDIO_CONFIG.instagramHandle}
                    </p>
                  </div>
                </div>
                <span className="text-xs text-[#db58ff] font-medium">Seguir</span>
              </a>

              {/* Location Card */}
              <div className="p-4 rounded-xl bg-[#090103] border border-white/5 flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-white/5 text-[#d6cad8] flex items-center justify-center">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs text-[#9c8a9e]">Região de Atuação</p>
                  <p className="text-xs sm:text-sm font-medium text-white">{STUDIO_CONFIG.location}</p>
                </div>
              </div>

            </div>

            {/* Differential Guarantee Box */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-[#1b0616] to-[#0c0817] border border-[#0099b9]/30 space-y-3">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Clock className="w-4 h-4 text-[#db58ff]" />
                <span>Precisa do site pronto ainda hoje?</span>
              </div>
              <p className="text-xs text-[#d6cad8] leading-relaxed">
                Avise diretamente no WhatsApp que você tem urgência. Analisaremos sua demanda imediatamente para alocar nossa esteira de desenvolvimento de entrega expressa no mesmo dia.
              </p>
              <a
                href={getWhatsAppLink('Olá Brenda! Tenho uma urgência comercial e preciso de um site entregue no mesmo dia. Como podemos iniciar agora?')}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0099b9] hover:text-[#28caee] transition-colors"
              >
                <span>Solicitar encaixe express no WhatsApp</span>
                <span>→</span>
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
