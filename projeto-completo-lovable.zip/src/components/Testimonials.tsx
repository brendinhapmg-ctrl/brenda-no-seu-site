import React from 'react';
import { Star, Quote, CheckCircle, ArrowRight, MessageCircle } from 'lucide-react';
import { TESTIMONIALS_DATA, getWhatsAppLink } from '../data/studioData';

export const Testimonials: React.FC = () => {
  return (
    <section id="depoimentos" className="py-20 md:py-28 relative overflow-hidden bg-[#10030b]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#0099b9] uppercase tracking-wider mb-2">
              <span>04</span>
              <span aria-hidden="true" className="text-[#9c8a9e]">·</span>
              <span>Depoimentos & Reputação</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight text-balance">
              Quem contratou viu o faturamento aumentar.
            </h2>
            <p className="text-base text-[#d6cad8] mt-3">
              Depoimentos de empresários, profissionais liberais e diretores que confiaram na Brenda No Seu Studio.
            </p>
          </div>

          {/* Social Proof Aggregator */}
          <div className="p-4 rounded-2xl bg-[#190614] border border-[#db58ff]/20 flex items-center gap-4 self-start md:self-auto shadow-md">
            <div className="flex items-center text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400" />
              ))}
            </div>
            <div className="text-xs">
              <span className="font-bold text-white">4.9 / 5.0</span>
              <span className="text-[#9c8a9e] ml-1">· Satisfação Máxima</span>
            </div>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {TESTIMONIALS_DATA.map((item) => (
            <div
              key={item.id}
              className="bg-studio-card rounded-2xl p-7 flex flex-col justify-between relative group hover:border-[#db58ff]/40 transition-all duration-300"
            >
              <div>
                {/* Rating and Quote Icon */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1 text-amber-400">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                    ))}
                  </div>
                  <Quote className="w-5 h-5 text-[#db58ff]/30 group-hover:text-[#db58ff]/60 transition-colors" />
                </div>

                {/* Highlight Title */}
                <h3 className="text-base font-bold text-white mb-3">
                  &ldquo;{item.highlight}&rdquo;
                </h3>

                {/* Body Quote */}
                <p className="text-sm text-[#d6cad8] leading-relaxed mb-6">
                  {item.quote}
                </p>

                {/* Quantitative Impact Tag */}
                <div className="py-2 px-3 rounded-lg bg-[#0e0208] border border-[#0099b9]/25 text-xs text-[#0099b9] font-medium flex items-center gap-2 mb-6">
                  <CheckCircle className="w-3.5 h-3.5 text-[#0099b9] shrink-0" />
                  <span>Resultado: <strong className="text-white">{item.impactResult}</strong></span>
                </div>
              </div>

              {/* Author Info */}
              <div className="pt-4 border-t border-white/5 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#db58ff] to-[#0099b9] flex items-center justify-center text-white font-bold text-xs tracking-wider shrink-0 shadow-sm">
                  {item.avatarText}
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white leading-tight">
                    {item.name}
                  </h4>
                  <p className="text-xs text-[#9c8a9e]">
                    {item.role} · <span className="text-[#d6cad8]">{item.company}</span>
                  </p>
                  <p className="text-[11px] text-[#db58ff] font-mono mt-0.5">
                    {item.city}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA to get quote */}
        <div className="mt-14 p-8 rounded-2xl bg-gradient-to-r from-[#170513] via-[#10030c] to-[#07131a] border border-[#db58ff]/25 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h4 className="text-lg font-bold text-white mb-1">
              Quer ver seu faturamento aumentar no próximo mês?
            </h4>
            <p className="text-xs sm:text-sm text-[#d6cad8]">
              Solicite uma análise rápida e gratuita do seu posicionamento digital com a Brenda.
            </p>
          </div>

          <a
            href={getWhatsAppLink('Olá Brenda! Vi os depoimentos e quero saber como você pode aumentar os resultados da minha empresa.')}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary px-6 py-3.5 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 whitespace-nowrap shrink-0 shadow-lg"
          >
            <MessageCircle className="w-4 h-4 fill-white/20" />
            <span>Falar com a Brenda no WhatsApp</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

      </div>
    </section>
  );
};
