/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Portfolio } from './components/Portfolio';
import { Testimonials } from './components/Testimonials';
import { Faq } from './components/Faq';
import { ContactForm } from './components/ContactForm';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

export default function App() {
  return (
    <div className="min-h-screen bg-[#090103] text-white flex flex-col font-sans selection:bg-[#db58ff]/30 selection:text-white">
      {/* Top Bar Navigation */}
      <Navbar />

      <main className="flex-1">
        {/* 1. Seção Inicial Impactante */}
        <Hero />

        {/* 2. Sobre / Quem Sou */}
        <About />

        {/* 3. Serviços */}
        <Services />

        {/* 4. Portfólio / Projetos */}
        <Portfolio />

        {/* 5. Depoimentos */}
        <Testimonials />

        {/* Perguntas Frequentes (FAQ) */}
        <Faq />

        {/* 6. Formulário de Contato */}
        <ContactForm />
      </main>

      {/* Footer Corporativo */}
      <Footer />

      {/* 7. WhatsApp Flutuante */}
      <FloatingWhatsApp />
    </div>
  );
}
